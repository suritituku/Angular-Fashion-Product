export interface customerInterface
{
id : number,
title : string,
price : number,
image : string
}